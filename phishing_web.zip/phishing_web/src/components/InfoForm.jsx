import React from 'react'

export default function InfoForm() {
  return (
    <div>InfoForm</div>
  )
}
